update locksettings set value=65536 where name='lockscreen.password_type';
