.header on
select * from sms;
