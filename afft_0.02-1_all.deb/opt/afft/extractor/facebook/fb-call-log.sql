.header on
select * from person_summary;
