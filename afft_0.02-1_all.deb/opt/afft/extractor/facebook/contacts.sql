.header on
select * from contacts;

