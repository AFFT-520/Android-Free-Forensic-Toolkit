# Android-Free-Forensic-Toolkit
The development place of AFFT, a toolkit to automatically acquire and extract data from Android image dumps
