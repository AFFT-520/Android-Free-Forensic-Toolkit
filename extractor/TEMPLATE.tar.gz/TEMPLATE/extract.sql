.header on --This makes column headers visible
SELECT * FROM tablename
