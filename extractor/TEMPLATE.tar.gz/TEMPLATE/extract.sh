#!/bin/bash

# This is the main script that runs during the extract stage.
# This script is always passed with the root of the case folder as $1.
# The SQLite statements required to extract the data are stored in seperate scripts and are called like so:
#
# sqlite3 $1/image/userdata/path-to-database < /opt/afft/extraction/example/example.sql > $1/extracted\ data/example/dump.txt

