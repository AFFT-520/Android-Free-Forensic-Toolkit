.header on
select * from gql_notifications;
